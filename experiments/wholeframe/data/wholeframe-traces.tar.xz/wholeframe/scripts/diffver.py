"""Diagnostic-level diff between checker versions on the same traces (and against the stored run)."""
import gzip, json, collections, sys
S = {}
for l in gzip.open('/tmp/wfr/raw_results.jsonl.gz'):
    r = json.loads(l); S[r['id']] = r
def load(p):
    return {json.loads(l)['id']: json.loads(l) for l in open(p)}
def dset(diags, full=True, warn=False):
    return collections.Counter((d['code'], d.get('res'), d['where'], d['message'] if full else '') for d in diags
                               if warn or d.get('severity', 'error') != 'warning')
def cmp(A, B, name, full=True, warn=False):
    ch = collections.Counter(); ids = collections.defaultdict(set)
    for i in sorted(A):
        a, b = dset(A[i], full, warn), dset(B[i], full, warn)
        for k, v in (a - b).items(): ch[('lost', k[0])] += v; ids[('lost', k[0])].add(i)
        for k, v in (b - a).items(): ch[('gained', k[0])] += v; ids[('gained', k[0])].add(i)
    nm = len(set().union(*ids.values())) if ids else 0
    print(f'{name}: {nm} mutants differ', {f'{k[0]} {k[1]}': (v, len(ids[k])) for k, v in sorted(ch.items())})
V = {v: load(f'/tmp/wfr/bisect/{v}.jsonl') for v in sys.argv[1:]}
D = {v: {i: r['diagnostics'] for i, r in V[v].items()} for v in V}
stored = {s: {i: S[i]['cov'][s]['diags'] for i in S} for s in ('snap', 'fix')}
if 'proto' in D: cmp(stored['snap'], D['proto'], 'stored snap -> proto on new traces')
if 'fix' in D: cmp(stored['fix'], D['fix'], 'stored fix -> fix on new traces')
vs = list(D)
seq = [v for v in ['fix', 'v2', 'v3', 'v31', 'v32', 'v33', 'v34'] if v in D]
for a, b in zip(seq, seq[1:]):
    cmp(D[a], D[b], f'{a} -> {b} (errors, full text)')
    cmp(D[a], D[b], f'{a} -> {b} (errors, code/where only)', full=False)
    cmp(D[a], D[b], f'{a} -> {b} (incl warnings, code/where)', full=False, warn=True)
for x in ('v34_disc', 'v34_obs'):
    if x in D: cmp(D['v34'], D[x], f'v34 -> {x} (incl warnings, code/where)', full=False, warn=True)
