#!/bin/bash
# Re-check every archived whole-frame trace (1,251 programs) with another COVENANT checker snapshot and
# recompute the agreement with the STORED Khronos-validation verdicts (validation is not re-run).
#
#   recheck.sh <checker-root> [label]
#
# <checker-root>: a snapshot directory that contains covenant/ (and normally tools/check_trace.py).
#                 It is only read: Python runs with -B / PYTHONDONTWRITEBYTECODE=1, cwd elsewhere.
# label:          name for the outputs (default: the snapshot's covenant_version hash).
# Environment:
#   ARCHIVE  the traces tarball (default: wholeframe-traces.tar.xz next to this script)
#   WORK     scratch dir (default /tmp/wfr-recheck); the archive is extracted once to $WORK/wholeframe
#   JOBS     parallel checks (default 4)
#   NO_TOOL=1  skip tools/check_trace.py (eligibility, all checkers; ~1 s/trace); timing-only takes ~5 s
#   COVENANT_HOST_CAPTURE / COVENANT_HEURISTIC_DISCARD / COVENANT_LEGACY_SUBPASS_FLAGS: passed through
#            (leave unset for the default, verified configuration)
# Output: $WORK/out-<label>/{cov_<label>.jsonl, tables_<label>.md/.json, changes_<label>.json,
#         analysis_<label>{,+afu}.json}; tables_<label>.md is also printed. Exit 1 on checker errors,
#         a failed self-check (stored tables not reproduced) or a missing input.
set -euo pipefail
HERE=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
[ $# -ge 1 ] || { sed -n 2,20p "$0"; exit 2; }
ROOT=$(cd "$1" && pwd) || { echo "no such checker root: $1" >&2; exit 2; }
[ -d "$ROOT/covenant" ] || { echo "$ROOT has no covenant/ package" >&2; exit 2; }
ARCHIVE=${ARCHIVE:-$HERE/wholeframe-traces.tar.xz}
WORK=${WORK:-/tmp/wfr-recheck}
JOBS=${JOBS:-4}
PY=${PYTHON:-python3}
export PYTHONDONTWRITEBYTECODE=1
BASE=$WORK/wholeframe
mkdir -p "$WORK"
if [ ! -f "$BASE/.extracted" ]; then
  [ -f "$ARCHIVE" ] || { echo "archive not found: $ARCHIVE (set ARCHIVE=)" >&2; exit 2; }
  echo "extracting $ARCHIVE -> $WORK" >&2
  rm -rf "$BASE"
  if xz --help 2>/dev/null | grep -q -- '-T'; then tar -I 'xz -T0' -xf "$ARCHIVE" -C "$WORK"; else tar -xJf "$ARCHIVE" -C "$WORK"; fi
  touch "$BASE/.extracted"
fi
n=$(ls "$BASE/runs" | wc -l)
[ "$n" -eq 1251 ] || { echo "expected 1251 run dirs in $BASE/runs, found $n" >&2; exit 1; }
# scripts: the ones next to this file if present (phase6/wholeframe/scripts), else the archived copy
S=$HERE/scripts; [ -f "$S/analyze34.py" ] || S=$BASE/scripts
for f in check_cov34.py analyze34.py analyze.py vvlparse.py; do
  [ -f "$S/$f" ] || { echo "missing $S/$f" >&2; exit 2; }
done
HASH=$(cd "$WORK" && $PY -B -c "import sys; sys.path.insert(0, '$S'); import check_cov34 as c; print(c.checker_version('$ROOT'))")
LABEL=${2:-$HASH}
OUT=$WORK/out-$LABEL
mkdir -p "$OUT"
TOOL=--with-check-trace
if [ "${NO_TOOL:-0}" = 1 ] || [ ! -f "$ROOT/tools/check_trace.py" ]; then TOOL=; fi
echo "checker $ROOT (covenant_version $HASH), label $LABEL, jobs $JOBS, check_trace: ${TOOL:-no}" >&2
t0=$(date +%s)
(cd "$WORK" && COVENANT_ROOT="$ROOT" $PY -B "$S/check_cov34.py" --root "$ROOT" --runs "$BASE/runs" \
   --mutants "$BASE/inputs/mutants.json" --jobs "$JOBS" $TOOL --out "$OUT/cov_$LABEL.jsonl")
t1=$(date +%s)
nerr=$($PY -B -c "import json,sys; print(sum(json.loads(l).get('error') is not None for l in open(sys.argv[1])))" "$OUT/cov_$LABEL.jsonl")
[ "$nerr" -eq 0 ] || { echo "$nerr traces failed to check; see 'error' in $OUT/cov_$LABEL.jsonl" >&2; exit 1; }
PREV=()
for p in release v34; do
  [ -f "$BASE/results/cov_$p.jsonl" ] && PREV+=(--prev "$p=$BASE/results/cov_$p.jsonl")
done
(cd "$WORK" && $PY -B "$S/analyze34.py" --base "$BASE" --cov "$OUT/cov_$LABEL.jsonl" --name "$LABEL" \
   --out "$OUT" "${PREV[@]}")
echo "check: $((t1 - t0)) s; outputs in $OUT" >&2
