#!/usr/bin/env python3
"""Attribute every per-mutant difference between the stored cov.fix results and v3.4 to a measured cause,
using re-checks of the SAME archived traces by intermediate checker versions and mode switches
(results/bisect/<version>.jsonl, check_cov34.py output):

  fix      covenant-proto + phase3 checker.patch (= the stored cov.fix checker)
  v2, v3, v31, v32, v33   shared covenant-v2 ... covenant-v33 packages
  v34      frozen v3.4 (default modes: strict discard, conservative host capture)
  v34_disc v3.4 with COVENANT_HEURISTIC_DISCARD=1 (R1, the v1-v3 default)
  v34_obs  v3.4 with COVENANT_HOST_CAPTURE=observed (the v1-v3 behaviour)
  v34_disc_obs  both

    python3 explain_changes.py --base BASE --out results/changes_explained.json

Fails (exit 1) if any difference is left unattributed.
"""
import argparse
import collections
import gzip
import json
import os
import sys


def load(p):
    with (gzip.open(p, "rt") if p.endswith(".gz") else open(p)) as f:
        return {r["id"]: r for r in map(json.loads, f)}


def dkeys(diags, full=False, warn=False):
    return collections.Counter((d["code"], d.get("res"), d.get("where"), d.get("message") if full else "")
                               for d in diags if warn or d.get("severity", "error") != "warning")


def hkeys(hz):
    return collections.Counter((h["code"], h["res"], h["e_q"], h["u_q"], h["e_where"], h["u_where"]) for h in hz)


CAUSE = {
    "v2-R1": "v2: R-1 first use of a never-presented swapchain image without the acquire wait is reported as "
             "the warning timing.acquire-first-use (excluded by analyze.py, which drops warnings)",
    "v31-1": "v3.1 change #1: spec-strict layout transitions from UNDEFINED by default (R1 relaxation now opt-in, "
             "COVENANT_HEURISTIC_DISCARD=1): earlier writes must be made AVAILABLE before the transition; the "
             "transition is the write later accesses are paired with",
    "v31-2": "v3.1 change #2: conservative host-write capture (whole written pages charged): consecutive host "
             "writes to one slot cover the same region, so the later one supersedes the earlier in the "
             "checker's state; hazard representative pairs change, diagnostics do not",
    "v31-3": "v3.1 change #3: sync2 signal stage masks limit every hop of a relay: the presentation engine's "
             "hold-until-reacquire read, and the re-acquired image's next use, are no longer credited with an "
             "ordering through a semaphore whose stage mask does not hold the write",
    "v31-10": "v3.1 change #10: diagnostics name the failed scope test; two hazards at one access that v3 "
              "worded identically (deduplicated by Report.add on (code, message, where)) now differ in text "
              "and are both reported; same hazard pairs",
}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--base", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--new", default="", help="check_cov34.py output to explain (default results/cov_v34.jsonl); "
                    "it must equal v3.4 diagnostics and hazards exactly, else its extra differences are listed "
                    "as unattributed")
    a = ap.parse_args()
    B = os.path.join(a.base, "results", "bisect")
    raw = load(os.path.join(a.base, "inputs", "raw_results.jsonl.gz"))
    V = {v: load(os.path.join(B, f"{v}.jsonl")) for v in
         ("fix", "v2", "v3", "v31", "v32", "v33", "v34_disc", "v34_obs", "v34_disc_obs")}
    V["v34"] = load(os.path.join(a.base, "results", "cov_v34.jsonl"))
    if a.new:
        NEW = load(a.new)
        same = [i for i in sorted(raw) if dkeys(NEW[i]["diagnostics"], True, True) == dkeys(V["v34"][i]["diagnostics"], True, True)
                and hkeys(NEW[i]["hazards"]) == hkeys(V["v34"][i]["hazards"])]
        out_extra = [i for i in sorted(raw) if i not in set(same)]
        print(f"{a.new}: identical to v3.4 (diagnostics incl. text and warnings, hazard pairs) on "
              f"{len(same)} of {len(raw)} programs")
    ids = sorted(raw)
    out = {"causes": CAUSE, "checks": {}, "mutants": {}, "unattributed": []}
    if a.new:
        out["new"] = a.new
        out["new_identical_to_v34"] = len(same)
        out["unattributed"] += [(i, "differs from v3.4: not covered by the v3.4 bisection") for i in out_extra]

    # 0. the new traces reproduce the stored diagnostics with the stored checker (full text, warnings incl.)
    out["checks"]["stored_fix_reproduced_on_new_traces"] = sum(
        dkeys(raw[i]["cov"]["fix"]["diags"], True, True) != dkeys(V["fix"][i]["diagnostics"], True, True) for i in ids) == 0
    out["checks"]["v31_v32_v33_v34_identical"] = all(
        dkeys(V[x][i]["diagnostics"], True, True) == dkeys(V["v34"][i]["diagnostics"], True, True) and
        hkeys(V[x][i]["hazards"]) == hkeys(V["v34"][i]["hazards"]) for x in ("v31", "v32", "v33") for i in ids)
    out["checks"]["fix_v2_v3_errors_identical"] = all(
        dkeys(V["fix"][i]["diagnostics"], True) == dkeys(V[x][i]["diagnostics"], True) for x in ("v2", "v3") for i in ids)
    for k, v in out["checks"].items():
        if not v:
            out["unattributed"].append(("check failed", k))

    tot = collections.Counter()
    for i in ids:
        mut = raw[i]["mut"]
        rec = collections.Counter()
        fx, v2, v3, vd, v4 = (V[x][i] for x in ("fix", "v2", "v3", "v34_disc", "v34"))
        # warnings (v2)
        w = dkeys(v2["diagnostics"], False, True) - dkeys(v2["diagnostics"]) - (dkeys(fx["diagnostics"], False, True) - dkeys(fx["diagnostics"]))
        for k, n in w.items():
            if k[0] == "timing.acquire-first-use":
                rec[("v2-R1", "gained warning " + k[0])] += n
            else:
                out["unattributed"].append((i, "warning", k))
        if dkeys(v2["diagnostics"], False, True) != dkeys(v4["diagnostics"], False, True) - (
                dkeys(v4["diagnostics"]) - dkeys(v2["diagnostics"])) + (dkeys(v2["diagnostics"]) - dkeys(v4["diagnostics"])):
            pass  # the error part is handled below; the warning part is v2-R1 only (checked by v31..v34 identity)
        # errors: v3 -> v34_disc (non-discard v3.1 changes), v34_disc -> v34 (strict discard)
        hz3, hzd = hkeys(v3["hazards"]), hkeys(vd["hazards"])
        for (k, n), sign in [(x, "gained") for x in (dkeys(vd["diagnostics"]) - dkeys(v3["diagnostics"])).items()] + \
                            [(x, "lost") for x in (dkeys(v3["diagnostics"]) - dkeys(vd["diagnostics"])).items()]:
            code, res = k[0], k[1]
            pairs_gained = any(h[0] == code and h[1] == res for h in hzd - hz3)
            same_pairs = (collections.Counter({h: c for h, c in hz3.items() if h[1] == res}) ==
                          collections.Counter({h: c for h, c in hzd.items() if h[1] == res}))
            if code == "timing.signal-stage-scope" and sign == "gained" and pairs_gained:
                rec[("v31-3", f"{sign} {code} on {res.split('[')[0]}")] += n
            elif code == "timing.barrier-scope" and sign == "gained" and pairs_gained and "signal_stage" in mut:
                rec[("v31-3", f"{sign} {code} on {res.split('[')[0]}")] += n
            elif code == "timing.barrier-scope" and sign == "gained" and same_pairs:
                rec[("v31-10", f"{sign} {code} on {res.split('[')[0]}")] += n
            else:
                out["unattributed"].append((i, "error v3->v34_disc", sign, k))
        for (k, n), sign in [(x, "gained") for x in (dkeys(v4["diagnostics"]) - dkeys(vd["diagnostics"])).items()] + \
                            [(x, "lost") for x in (dkeys(vd["diagnostics"]) - dkeys(v4["diagnostics"])).items()]:
            rec[("v31-1", f"{sign} {k[0]} on {(k[1] or '').split('[')[0]}")] += n
        # text-only (same code/where multiset, different message) between v3 and v34
        if dkeys(v3["diagnostics"]) == dkeys(v4["diagnostics"]) and \
                dkeys(v3["diagnostics"], True) != dkeys(v4["diagnostics"], True):
            rec[("v31-10", "message text only")] += 1
        # hazard pairs: conservative vs observed capture
        hz_obs = hkeys(V["v34_obs"][i]["hazards"])
        hz4 = hkeys(v4["hazards"])
        if hz_obs != hz4:
            if dkeys(V["v34_obs"][i]["diagnostics"], True, True) == dkeys(v4["diagnostics"], True, True) and \
                    all(h[2] == "host" or h[3] == "host" for h in (hz_obs - hz4) + (hz4 - hz_obs)):
                rec[("v31-2", f"lost {sum((hz_obs - hz4).values())} host hazard pairs, gained "
                              f"{sum((hz4 - hz_obs).values())}; diagnostics identical")] += 1
            else:
                out["unattributed"].append((i, "host capture changes diagnostics"))
        if rec:
            out["mutants"][i] = {"mut": mut, "config": raw[i]["config"],
                                 "deltas": [{"cause": c, "what": w, "n": n} for (c, w), n in sorted(rec.items())]}
            for (c, w), n in rec.items():
                tot[(c, w)] += n
    out["totals"] = [{"cause": c, "what": w, "n": n,
                      "mutants": sum(1 for m in out["mutants"].values()
                                     if any(d["cause"] == c and d["what"] == w for d in m["deltas"]))}
                     for (c, w), n in sorted(tot.items())]
    json.dump(out, open(a.out, "w"), indent=1)
    for t in out["totals"]:
        print(f"{t['cause']:7s} {t['n']:5d} in {t['mutants']:4d} mutants  {t['what']}")
    print("checks", out["checks"])
    print("unattributed", len(out["unattributed"]), out["unattributed"][:10])
    sys.exit(1 if out["unattributed"] else 0)


if __name__ == "__main__":
    main()
