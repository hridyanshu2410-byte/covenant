import json,collections,sys
def load(p): return {json.loads(l)['id']: json.loads(l) for l in open(p)}
def hz(r): return collections.Counter((h['code'],h['res'],h['e_q'],h['u_q'],h['e_where'],h['u_where']) for h in r['hazards'])
def cmp(a,b):
    A,B=load(f'/tmp/wfr/bisect/{a}.jsonl'),load(f'/tmp/wfr/bisect/{b}.jsonl')
    ch=collections.Counter(); ids=collections.defaultdict(set)
    for i in A:
        x,y=hz(A[i]),hz(B[i])
        for k,v in (x-y).items(): ch[('lost',k[0],k[1].split('[')[0])]+=v; ids[('lost',k[0],k[1].split('[')[0])].add(i)
        for k,v in (y-x).items(): ch[('gained',k[0],k[1].split('[')[0])]+=v; ids[('gained',k[0],k[1].split('[')[0])].add(i)
    print(f'{a} -> {b}: hazard pairs')
    for k,v in sorted(ch.items()): print('   ',k,v,len(ids[k]),sorted(ids[k])[:6])
    return ids
for a,b in zip(sys.argv[1::2],sys.argv[2::2]): cmp(a,b)
