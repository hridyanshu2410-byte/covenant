# Whole-frame differential test: COVENANT side regenerated, traces archived, re-checked with the release

**Date:** 2026-10-18. **What this is:** a regression re-run of the existing suite
`phase3/wholeframe-difftest` (1,251 programs: 5 baselines + 1,246 mutants of workloads W1/W2/W3 in the
5 configurations W1-F2, W1-F3, W2, W3, W2-MQ). It is not a new study.
- **Regenerated:** the COVENANT side (model-driver run → trace → `host_trace.load_trace` +
  `timing.check(window=False)`).
- **Not re-run:** Khronos validation. Its stored verdicts (`raw_results.jsonl.gz`: lavapipe+VVL `sv`,
  mock ICD+VVL `mock`) are the reference, exactly as before.
- **New this time:** every trace is archived.

## Summary

- **Primary checker: the final release** `/tmp/rel/release`, `covenant_version` **`8e472acb13f0`**
  (git `1ce1e7a` "release: framebuffer token in epoch read keys, A-HOST premise warning, eligibility
  report").
- **Comparison checker:** the frozen v3.4 snapshot `1e229f5473a8` (= `phase5/checker-v34/freeze.txt`).
- **Baselines behave as the stored RESULTS.md says.** All 5 baselines report 0 diagnostics and 0
  warnings under both checkers: the 4 single-queue baselines are clean, and so is the multi-queue
  baseline (W2-MQ).
- **Agreement with the stored validation verdicts is unchanged.** Same method as `analyze.py`, over
  all 1,251 programs, W2-MQ baseline-relative:

  | verdict = "at least one finding" | stored snap | stored fix | **v3.4** | **release** |
  |---|---|---|---|---|
  | hazards only | 88.4% | 97.9% | **97.9%** | **97.9%** |
  | all finding classes | 84.3% | 95.4% | **95.4%** | **95.4%** |
  | (mutant, finding) pairs, all classes: both / COVENANT only / VVL only | 1270 / 413 / 1199 | 2353 / 478 / 116 | **2353 / 478 / 116** | **2353 / 478 / 116** |
  | (mutant, resource) hazard pairs: both / COVENANT only / VVL only | | 1440 / 32 / 14 | **1440 / 32 / 14** | **1440 / 32 / 14** |
  | triage: unexplained keys / rows changed vs stored fix | | 0 / – | **0 / 0** | **0 / 0** |

  With `timing.acquire-first-use` counted as a hazard (`+afu`, the view phase 4 used for v3.1), both
  checkers give 98.3% / 95.8%, pairs 2367 / 511 / 102, hazard pairs 1454 / 65 / 0. This is identical
  to v3.1+afu.
- **Changed COVENANT verdicts versus the stored `cov.fix`: 0.** That holds for the all-classes
  verdict, the hazards-only verdict, and the normalised (class, object) key set, in all 1,251
  programs. Release vs v3.4 is identical at every level: diagnostics including message text and
  warnings, and hazard pairs. Per-mutant keys and triage are also identical to the stored v3.1
  re-run (`phase4/checker-v31/results/wholeframe/analysis_v31{,+afu}.json`).
- **Below the verdict level:**
  - 106 programs changed in diagnostic code/location;
  - 435 programs changed only in message text;
  - 104 programs gained `acquire-first-use` warnings;
  - 11 programs changed only in recorded hazard representative pairs.

  Every one of these is attributed by measurement, by re-checking the same traces with every
  intermediate checker version and with mode switches (0 unattributed; §"What changed"). None comes
  from v3.4's three changes (framebuffer-local dependencies, render-pass/render-pass transition
  pairs, descriptor refinement), nor from the release's changes: **v3.3 = v3.4 = release, byte for
  byte, on these traces.** The workloads have no BY_REGION/VIEW_LOCAL flag (all 30 barriers per trace
  have `dependency_flags: []`), no render pass (dynamic rendering), no descriptor-array guard
  (`desc_refine` is null everywhere), and no device write followed by a host write, so 0 A-HOST
  premise pairs. Every change dates from v2 or v3.1.
- **Guarantee eligibility** (release `tools/check_trace.py` stats field `eligibility`, recorded per
  program): **1,251 / 1,251 eligible.** For every program: `verified_configuration: true`,
  `checking_complete: true`, `model_gaps: []`, `host_domain_premise_pairs: 0`. It equals
  `timing.check`'s `report.meta["covenant.eligibility"]` in all 1,251 programs. The timing-code counts
  of `check_trace.py` (all checkers, as `bench/run.py`) equal the timing-only check in all 1,251. It
  adds no non-timing error codes; the only warning is `timing.acquire-first-use` (104 programs).
- **Runtime:**
  - 1,251 model-driver runs: 10.4 s wall (4 jobs).
  - v3.4 timing-only check: 4.1 s wall (4 jobs); median 6.3 ms load + 3.1 ms check.
  - Release, timing-only check plus `tools/check_trace.py` per trace: 949 s wall (2 jobs, alongside
    another regression); `check_trace.py` median 1.58 s per trace including interpreter start-up.
  - `recheck.sh` from the tarball: about 15 s in total timing-only (2 jobs, including extraction); a
    few minutes with the eligibility tool at 4 jobs.
- **Archive:** `wholeframe-traces.tar.xz`, 3.3 MB (224 MB unpacked). It holds all 1,251 traces with
  `spv/`, `out/err/status`, the run records, all checker results and the scripts.

## Method

1. **Builds (scratch `/tmp/wfr`):**
   - `wf.cpp`: `clang++-20 -std=c++17 -O1 -l:libvulkan.so.1 -lxcb` (clang 20.1.2). Shaders:
     `glslangValidator -V` 15.1.0.
   - Snapshot: `covenant-v34-frozen.tar.gz` extracted to `/tmp/wfr/fz34`. Its prebuilt driver hashes
     match `freeze.txt`.
   - Driver: rebuilt with `rm -f model_driver/build/covvk_*.inc; make -C model_driver
     VKINC=/tmp/re2/vkh/include VKH=/tmp/re2/vkh/include/vulkan/vulkan_core.h all` (Vulkan-Headers
     1.4.365).
   - **The rebuilt `libcovvk.so` was used.** Its `.text` and `.rodata` are byte-identical to the
     shipped `drv/libcovvk.so`; only debug paths differ.
   - The release's `model_driver/covvk.cpp` is identical to v3.4's, and its prebuilt `libcovvk.so`
     has the same `.text`. So the traces are valid for the release as recorded; no re-trace was
     needed.
2. **Runs** (`scripts/runner34.py`, 4 at a time):
   - Environment as in `run_cov.sh`: `COVENANT_TRACE`, `COVENANT_SPIRV_DIR`,
     `COVENANT_SURFACE_EXTENT=64x64`, `LD_LIBRARY_PATH=<driver build>`, `WF_SHADERS`, `WF_IMAGES=3`,
     `WF_MUT`.
   - Surface: as in the stored run. W1-F2/W1-F3/W2/W3 use an **X11 surface on Xvfb**, one display per
     worker (`:191`–`:194`, started and stopped by PID); W2-MQ uses `VK_EXT_headless_surface`
     (`WF_XCB=0`).
   - All 1,251 runs exit 0. The acquire order and the applied-mutation list equal the stored run for
     every mutant.
   - 4 runs hit a transient `FATAL no X display` at `xcb_connect` and were retried once
     (`x_retries` in `runs.jsonl`: W1-F3-0191, W2-0115, W3-0001, W3-0175).
3. **Checks** (`scripts/check_cov34.py`):
   - Same as `phase3/scripts/check_cov.py`: `load_trace(trace, spirv_dir)` + `timing.check(frame,
     Report(), hazards=hz, window=False)`.
   - Default modes: strict discard, conservative host capture, local legacy subpass flags; the
     verified configuration is recorded per program.
   - Per program it records: id, config, mutant, diagnostics (code, res, where, message, notes,
     severity, hazard flag), hazard pairs, warnings, unsupported notes, timings, and eligibility.
     With `--with-check-trace` it also records the release's `tools/check_trace.py` stats (incl.
     `eligibility`) and finding codes.
   - Batch mode equals a fresh process per trace (40-trace sample, identical diagnostics).
   - The release was only read: `-B` and `PYTHONDONTWRITEBYTECODE=1`, md5 manifest before/after.
     See "Notes" for what changed there during the run, not by this job.
4. **Scoring** (`scripts/analyze34.py`), as `phase4/checker-v31/scripts/wf_tables.py` did:
   - The `vvl.txt` files were never archived, so `analyze.load_msgs` is replaced by the stored parsed
     messages.
   - The new results go on `analyze.py`'s "fix" side, and its own `main()` runs unchanged:
     normalisation, W2-MQ baseline-relative view, tables, triage rules.
   - **Self-check:** with the stored `snap`/`fix` results the script must reproduce the stored
     numbers (88.4/84.3, 97.9/95.4, 1270/413/1199, 2353/478/116, 0 unexplained). It does, and it
     aborts otherwise.
5. **Attribution of every difference** (`scripts/explain_changes.py`):
   - The same traces were re-checked by `covenant-proto` (= stored snap), proto + `checker.patch`
     (= stored fix), and the shared `covenant-v2`, `-v3`, `-v31`, `-v32`, `-v33` packages (copied to
     `/tmp`). `covenant-v33` hashes to `76e393826ae9` = its freeze.
   - v3.4 was also run with `COVENANT_HEURISTIC_DISCARD=1`, with `COVENANT_HOST_CAPTURE=observed`,
     and with both (`results/bisect/`).

## Per configuration (release; identical to stored fix and to v3.4)

| config | n | hazards: both / neither / COV only / VVL only | agree | all: both / neither / COV only / VVL only | agree |
|---|---|---|---|---|---|
| W1-F2 | 259 | 167 / 85 / 5 / 2 | 97.3% | 200 / 42 / 10 / 7 | 93.4% |
| W1-F3 | 259 | 153 / 97 / 8 / 1 | 96.5% | 189 / 59 / 7 / 4 | 95.8% |
| W2 | 239 | 151 / 84 / 1 / 3 | 98.3% | 183 / 43 / 10 / 3 | 94.6% |
| W3 | 245 | 168 / 72 / 2 / 3 | 98.0% | 203 / 34 / 7 / 1 | 96.7% |
| W2-MQ | 249 | 145 / 103 / 0 / 1 | 99.6% | 188 / 52 / 8 / 1 | 96.4% |
| ALL-SQ | 1002 | 639 / 338 / 16 / 9 | 97.5% | 775 / 178 / 34 / 15 | 95.1% |

Other counts:
- ALL-SQ (mutant, resource) hazard pairs: 1163 / 32 / 13, plus 135 host-write races.
- ALL-SQ (mutant, finding) pairs: 1833 / 364 / 106.
- W2-MQ: 277 / 0 / 1, plus 70 host-write races; pairs 520 / 114 / 10.

**Triage:** every disagreeing (mutant, finding) pair gets the same class as in the stored fix side.
- COVENANT only: VAL-LIMIT host races 205, TECH 114 + 76 + 9 + 2, DRIVER 51 + 4, MODEL 13 + 1,
  VAL-LIMIT ownership 3.
- VVL only: TECH 75, DRIVER 23, MODEL R-1 14 + 4.
- 0 rows changed, 0 unexplained.

**`+afu` view:** 25 programs change triage, by these rules only:
- the 18 VVL-only R-1 MODEL pairs become agreements;
- 26 cov-only DRIVER keys and 7 cov-only TECH keys appear: the `acquire-first-use` follow-ons after
  a skipped present or a re-signalled semaphore;
- 4 vvl-only TECH keys appear.

## What changed versus the stored `cov.fix` (none of it changes a verdict or a key)

Two control checks come first:
1. **Same traces, same old checker.** `covenant-proto` and proto + `checker.patch` reproduce the
   stored `cov.snap` and `cov.fix` diagnostics on the new traces **byte for byte** (code, object,
   where, message, warnings), in all 1,251 programs. So the new driver and the regenerated traces
   change nothing. Every difference below is a checker change.
2. **Which versions changed anything.** fix→v2 adds only warnings. v2→v3 changes nothing.
   v3.1 = v3.2 = v3.3 = v3.4 = release, byte for byte, including hazard pairs. **Every change happened
   in v2 or at v3→v3.1.**

| cause (measured) | effect | programs |
|---|---|---|
| **v2, R-1 as a warning:** `timing.acquire-first-use`, first use of a never-presented swapchain image without waiting on its acquire | +657 warnings. `analyze.py` drops warnings, so verdicts are unaffected; the `+afu` view counts them | 104 |
| **v3.1 #10, diagnostics name the failed scope test** (execution / availability / visibility) | message text only: the same code/where multiset, the text of `barrier-scope` messages reworded | 435 |
| **v3.1 #10, same as above:** two hazards at one access that v3 worded identically were merged by `Report.add` on (code, message, where). They now differ in text, so both are reported. Hazard pairs are identical (checked) | +16 `barrier-scope` on `particles` (W1-F3 `b_sbuf_war`: one earlier vertex read from frame f−1 and one from f−2); +5 on `offscreen0` | 4 + 1 |
| **v3.1 #3, sync2 signal stage masks limit every hop of a relay** | +180 `signal-stage-scope` (+184 pairs) on `swapchain[i]`, in `signal_stage:{none,wrong,late}` mutants. Each new pair has the **same image and the same earlier write** (the final transition) as a pair v3 already reported at `vkQueuePresentKHR` (184/184 checked). 181 sit at the presentation engine's "shows swapchain[i] until the next acquire" read: the second hop through the filtered `render_sem` signal, which v3 credited | 73 |
| **v3.1 #3, same as above** | +6 `barrier-scope` WAW pairs on `swapchain[i]`: the final transition of frame f vs. the blit of frame f+3 after re-acquire. The only path is `render_sem` (stage-masked) → present → acquire → wait; the fence is dropped (`signal_stage:*` + `fence_wait:drop`) | 3 (W1-F2-0198, W1-F3-0181, W1-F3-0242) |
| **v3.1 #1, spec-strict transitions from UNDEFINED** (R1 now opt-in; switching `COVENANT_HEURISTIC_DISCARD=1` on removes exactly these differences). W3 `b_depth` is an UNDEFINED→DEPTH_ATTACHMENT transition every frame | −384 `barrier-scope` on `depth` (−636 pairs) in `b_depth:dst_{none,wrong,access_none}`. Under R1, v3 also paired each later depth write with the previous frame's depth writes. Under strict, the transition is the write that orders those (its src scope holds them), and the frame's own transition with the mutated dst scope is reported (`depth`, same key) | 23 |
| **v3.1 #1, same as above** | +26 `barrier-scope` on `depth` in `b_depth:src_access_none`: "the earlier write … is not made available before the layout transition … from UNDEFINED". Strict requires availability; R1 only an execution dependency | 5 |
| **v3.1 #1, same as above** | +9 / −1 `barrier-scope` on `swapchain[i]`: a blit write, then the next UNDEFINED→TRANSFER_DST `b_sc_dst` of the same image, ordered only by execution (`fence_wait:drop` with `present_wait:drop` / `present:skip` / `signal_stage`) | 5 |
| **v3.1 #2, conservative host capture** (whole written pages; with `COVENANT_HOST_CAPTURE=observed` v3.4 has exactly v3's host pairs) | −20 host hazard pairs, **diagnostics identical**. Example W3-0013: the observed runs of frames 2 and 4 are `[0,768)` and `[0,767)`; conservatively both are the whole page, so the later host write supersedes the earlier one in the checker's state | 11 |

Programs per cause:
- v3.1 #1, depth lost (23): W3-0033, -0034, -0035, -0080, -0081, -0082, -0096, -0108, -0115, -0133,
  -0135, -0156, -0162, -0180, -0190, -0197, -0200, -0208, -0212, -0214, -0215, -0221, -0233.
- v3.1 #1, depth gained: W3-0032, -0079, -0120, -0151, -0178.
- v3.1 #1, swapchain: W1-F2-0116, -0122, -0198, W1-F3-0175, -0181.
- v3.1 #10, particles/offscreen0: W1-F3-0018, -0021, -0022, -0222, W1-F2-0183.
- v3.1 #2, host pairs: W3-0013, -0117, -0154, -0185; W1-F3-0014, -0129, -0137, -0166, -0189, -0251;
  W2-MQ-0150.
- v3.1 #3: the 73 programs listed in `results/changes_explained_release.json`.

That file also gives each program's deltas with their cause.

**Findings: nothing outside the expected sources changes a verdict.** The diagnostic-level changes
above are all documented v2/v3.1 changes that this suite had not been re-checked against at the
diagnostic level before. The phase-4 v3.1 re-run compared keys only.

The **expected v3.4 sources** (framebuffer-local dependencies, render-pass/render-pass transition
pairs, descriptor refinement) and the **release's additions** (`fb` in epoch read keys, the A-HOST
premise warning) have **nothing to act on in these workloads**. This is now measured (v3.3 = v3.4 =
release, byte for byte). `phase5/v34/REGRESSION.md` §3a could only argue it, because the traces were
gone.

## Files

- `wholeframe-traces.tar.xz` (unpacks to `wholeframe/`):
  - `runs/<id>/`: `trace.jsonl`, `spv/`, `out.txt`, `err.txt`, `status.txt`.
  - `runs.jsonl`: per-run rc, time, acquire order, applied mutations, X retries.
  - `inputs/`: `mutants.json` and `raw_results.jsonl.gz`, copied unchanged from phase3; the stored
    validation verdicts and old checker results.
  - `results/cov_release.jsonl`: the primary per-program results, with `check_trace.eligibility`.
  - `results/cov_v34.jsonl`.
  - `results/analysis_*.json`, `tables_*.{md,json}`, `changes_*.json`, `changes_explained_*.json`.
  - `results/bisect/*.jsonl`: proto, fix, v2–v3.3, v3.4 mode variants.
  - The release md5 manifests from before and after the run.
  - `VERSIONS.txt`.
  - `scripts/`.
- `scripts/`: `runner34.py` (new: COVENANT-only runner with X retry), `check_cov34.py` (new:
  `check_cov.py` adapted to v3.4+, batch, eligibility, optional `check_trace.py`), `analyze34.py`
  (new: scoring and comparison), `explain_changes.py`, `diffver.py`, `hazdiff.py` (attribution).
  `analyze.py` and `vvlparse.py` are unchanged copies from phase3, needed by `analyze34.py`.
- `recheck.sh <checker-root> [label]`:
  - It extracts the tarball once (`WORK`, default `/tmp/wfr-recheck`) and checks all 1,251 traces
    (`JOBS`, default 4; `NO_TOOL=1` skips `tools/check_trace.py`).
  - It rescores against the stored verdicts, with the self-check, and compares per program with the
    archived release and v3.4 results.
  - It prints the tables and exits non-zero on checker errors or a failed self-check.
  - Tested from the tarball on v3.4 and on the release.

## Notes and limitations

- **The release directory changed during the run, but not by this job and not in the checker.** A
  tests-only commit `f9f645c` ("tests: bundle the appendix's minimal frames", 06:07:45) added
  `tests/fixtures/minimal_frames/*` and changed `tests/test_v31.py`.
  - `covenant/__pycache__` and `covenant/signatures/__pycache__` appeared at 06:07:23. The
    concurrent regression runs `python3 tools/check_trace.py` without `-B`.
  - `covenant/*.py`, `bench/run.py` and `tools/check_trace.py` did not change: the hash is
    `8e472acb13f0` before and after, and in all 1,251 `check_trace.py` stats.
- **The suite:** 6 frames, 64x64, the designed mutation catalogue, and VVL as the reference (not
  ground truth). See the phase3 RESULTS.md. The model driver keeps its round-robin, never-blocking
  acquire and `minImageCount` 2, so the DRIVER triage classes are unchanged.
- **Timings:** model-driver run times (median 32 ms vs. 22 ms stored) and the release check times were
  measured while other jobs shared the 4 cores. They are not a speed claim.
